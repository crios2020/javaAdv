package chat;

public interface I_Txa {
    void clear();
    String getText();
    void setText(String text);
    void appendText(String text);
}
