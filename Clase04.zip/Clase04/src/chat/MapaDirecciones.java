package chat;

import java.util.Map;
import java.util.TreeMap;

public class MapaDirecciones {
    public static Map<String,String>getMapa(){
        Map<String,String>map=new TreeMap();
        map.put("Carlos", "192.168.0.3");
        map.put("Alejandro", "192.168.0.4");
        map.put("Ana", "192.168.0.3");
        return map;
    }
}
