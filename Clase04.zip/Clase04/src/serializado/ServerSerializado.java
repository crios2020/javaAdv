package serializado;

import java.net.ServerSocket;

public class ServerSerializado {
    public static void main(String[] args) {
        try (ServerSocket so=new ServerSocket(7000)){
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
