package serializado;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class App {
    public static void main(String[] args) {
        
        File file=new File("personas.dat");
        
        //Serializado
        try (ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(new Persona("Andrea", "Moretti", 26, 60));
            out.writeObject(new Persona("Juan", "Salas", 28, 120));
            out.writeObject(new Persona("Lorena", "Marasco", 41, 76));
            out.writeObject(new Persona("Marcos", "Lescano", 26, 60));
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //Deserializado
        try (ObjectInputStream in=new ObjectInputStream(new FileInputStream(file))){
            while(true){
                Persona p=(Persona)in.readObject();
                System.out.println(p);
            }
        } catch (ClassCastException e){ System.out.println("Tipo de objeto incorrecto!");
        } catch (EOFException e) { System.out.println("-- Fin del archivo! --");
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }
}
