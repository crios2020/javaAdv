package sockets;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Comparator;

public class ClienteMinimo2 {
    public static void main(String[] args) {
        String line;
        try (BufferedReader in=new BufferedReader(
                new InputStreamReader(
                        new Socket("localhost",5000).getInputStream()))) {
            //while((line=in.readLine())!=null){
            //    System.out.println(line);
            //}
            
            //in.lines().forEach(s->System.out.println(s));
            
            //in.lines().forEach(System.out::println);
            
            //in.lines().filter(s->s.toLowerCase().contains("o")).forEach(System.out::println);
            
            //in.lines().sorted().forEach(System.out::println);
            
            //in.lines().sorted(Comparator.reverseOrder()).forEach(System.out::println);
            
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
