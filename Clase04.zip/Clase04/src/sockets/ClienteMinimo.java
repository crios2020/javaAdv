package sockets;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClienteMinimo {
    public static void main(String[] args){
        int car;
        try (
                //Socket so=new Socket("localhost",5000);
                //InputStream in=so.getInputStream();
                //InputStream in=new Socket("localhost",5000).getInputStream();
                InputStreamReader in=new InputStreamReader(new Socket("localhost",5000).getInputStream());
                ){
            while((car=in.read())!=-1){
                System.out.print((char)car);
            }
            
            //for(byte b:in.readAllBytes()) System.out.print((char)b);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
