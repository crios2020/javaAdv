package saludo;

public class Saludo {
    public synchronized  void saludar(String nombre, boolean esJefe){
        if(esJefe){
            System.out.println("Jefe: Hola Llegue!!!!");
            notify();
            try { Thread.sleep(10); } catch(Exception e) { }
            notify();
            try { Thread.sleep(10); } catch(Exception e) { }
            notify();
            try { Thread.sleep(10); } catch(Exception e) { }
            notifyAll();
        }else{
            System.out.println(nombre+": llegue!!");
            try { wait(); } catch(Exception e) { }
            System.out.println(nombre+": Hola Jefe!");
        }
        
    }
}
