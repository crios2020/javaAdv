package ocp;

import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {
        //String[] vector={"primavera","verano","otoño","invierno"};
        //metodo1(vector);
        //metodo2(vector);
        //metodo2("primavera","verano","otoño","invierno");
        
        final int[] vector=new int[5];
        vector[0]=2;
        
        //vector=new int[5];
        
        final List<String>list=new ArrayList();
        list.add("hola");
        //list=new ArrayList();
    }
    
    public static void metodo1(String[] vector){
        for(int a=0;a<vector.length;a++){
            System.out.println(vector[a]);
        }
    }
    
    public static void metodo2(String... args){
        for(int a=0;a<args.length;a++){
            System.out.println(args[a]);
        }
    }
}
