package saludo;

public class App {
    public static void main(String[] args) {
        
        Saludo saludo=new Saludo();
        
        Empleado laura=new Empleado("Laura",false,saludo);
        Empleado jose=new Empleado("Jose",false,saludo);
        Empleado maria=new Empleado("Maria",false,saludo);
        Empleado juan=new Empleado("Juan",false,saludo);
        Empleado jefe=new Empleado("Jefe",true,saludo);
        
        laura.start();
        jose.start();
        maria.start();
        juan.start();
        try { Thread.sleep(1000); } catch (Exception e) {}
        jefe.start();
        
    }
}
