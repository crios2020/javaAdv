package hilos;

import java.io.FileWriter;

public class HiloFile extends Thread {

    private String file;

    public HiloFile(String file) {
        this.file = file;
    }

    @Override
    public void run() {
        for (int a = 1; a <= 20; a++) {
            try (FileWriter out = new FileWriter(file,true)) {
                out.write(file + " " + a + "\n");
                System.out.println(file + " " + a);
                Thread.sleep(1000);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

}
