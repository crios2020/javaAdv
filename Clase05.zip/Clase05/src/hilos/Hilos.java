package hilos;

public class Hilos {
    public static void main(String[] args) {
        HiloFile hf1=new HiloFile("hf1");
        HiloFile hf2=new HiloFile("hf2");
        HiloFile hf3=new HiloFile("hf3");
        HiloFile hf4=new HiloFile("hf4");
        hf1.start();
        hf2.start();
        hf3.start();
        hf4.start();
        
        try {
            hf1.join();
            hf2.join();
            hf3.join();
            hf4.join();
            //Thread.sleep(4000);
        } catch (Exception e) { }
        
        System.out.println("Leyendo Archivos ...");
        
        HiloFileRead hfr1=new HiloFileRead("hf1");
        HiloFileRead hfr2=new HiloFileRead("hf2");
        HiloFileRead hfr3=new HiloFileRead("hf3");
        HiloFileRead hfr4=new HiloFileRead("hf4");
        
        hfr1.start();
        hfr2.start();
        hfr3.start();
        hfr4.start();
    }
}
