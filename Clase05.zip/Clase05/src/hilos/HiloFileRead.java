package hilos;

import java.io.BufferedReader;
import java.io.FileReader;

public class HiloFileRead extends Thread{
    private String file;

    public HiloFileRead(String file) {
        this.file = file;
    }

    @Override
    public void run() {
        String line;
        try (BufferedReader in=new BufferedReader(new FileReader(file))){
            //in.lines().forEach(st->{
            //    System.out.println(st);
            //    try { Thread.sleep(1000); } catch (Exception e) {}
            //});
            while((line=in.readLine())!=null){
                System.out.println(line);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
