
package sockets;

public class App {
    public static void main(String[] args) {
        
        /*
        
            Protocolo TCP     
        
            SERVER                                              CLIENT
            ------------------                                  ------------------
            ServerSocket ss=new ServerSocket(int port);         Socket socket=new Socket(String ip, int port)
            ss.accept();
            ------------------                                  ------------------
            
            OutputStream        ------------------------->      InputStream
        
            InputStream         <-------------------------      OutputStream
        
            ------------------                                  ------------------
            ss.close();                                         socket.close();
        
            
            BufferedReader - BufferedWriter: transporta buffers de bytes.
            DataInputStream - DataOutputStream: transporta tipo de datos primitivos.
            ObjectInputStream - ObjectOutputStream: transporta objetos de java.
            
        
        */
        
    }
}
