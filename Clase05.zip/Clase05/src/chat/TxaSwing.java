package chat;

import javax.swing.JTextArea;

public class TxaSwing implements I_Txa {
    private JTextArea txa;

    public TxaSwing(JTextArea txa) {
        this.txa = txa;
    }

    @Override
    public void clear() {
        txa.setText("");
    }

    @Override
    public String getText() {
        return txa.getText();
    }

    @Override
    public void setText(String text) {
        txa.setText(text);
    }

    @Override
    public void appendText(String text) {
        txa.append(text);
    }
    
}
