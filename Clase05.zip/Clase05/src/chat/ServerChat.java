package chat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;

public class ServerChat implements Runnable{

    private I_Txa txa;

    public ServerChat(I_Txa txa) {
        this.txa = txa;
    }

    @Override
    public void run() {
        try (ServerSocket ss=new ServerSocket(9000)){
            while(true){
                try (   Socket so=ss.accept();
                        BufferedReader in=new BufferedReader(
                            new InputStreamReader(so.getInputStream()))
                ){
                    String ip=so.getInetAddress().getHostAddress();
                    String nombre="idk";
                    Map<String,String> map=MapaDirecciones.getMapa();
                    for(String k:map.keySet()){
                        if(map.get(k).equals(ip)){
                            nombre=k;
                        }
                    }
                    String mensaje=in.readLine();
                    txa.appendText(nombre+": "+mensaje+"\n");
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
